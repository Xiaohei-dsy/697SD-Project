import cv2
import numpy as np
from path import Path
path = Path("jenga-seq5/Depth")
imgs = sorted(path.files('*.png'))
for imgp in imgs:
    img = cv2.imread(imgp)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img2 = np.zeros_like(img)
    img2[:,:,0] = gray
    img2[:,:,1] = gray
    img2[:,:,2] = gray
    cv2.imwrite(Path("home/linghaomeng_umass_edu/697sd/processed_data/campus-center-seq2/Depth")/imgp, img2)
