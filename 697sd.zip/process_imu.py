import numpy as np
import csv
nn = np.genfromtxt("imu_data.txt",delimiter=',',usecols=(1,2,3,7,8,9),skip_header=1)

timestamp = []
with open("imu_data.txt",'r') as f:
        reader = csv.reader(f)
        reader.__next__()
        for row in reader:
            timestamp.append(row[0])
for i in range (len(nn)):
    np.savetxt(timestamp[i]+'.txt', nn[i],fmt='%f',newline=',')