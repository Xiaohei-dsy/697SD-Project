import torch

print(torch.cuda.is_available())

device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

print(device)

x = torch.tensor([1,2]).cuda()